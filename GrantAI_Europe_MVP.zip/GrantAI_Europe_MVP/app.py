import json, os
from datetime import datetime, timezone
from pathlib import Path
import pandas as pd
import requests
import streamlit as st
from dateutil import parser as dtparser
from openai import OpenAI

ROOT=Path(__file__).parent
PROFILE=ROOT/'data/profile.json'
SAVED=ROOT/'data/saved_opportunities.json'
EC_URL='https://api.tech.ec.europa.eu/search-api/prod/rest/search'

st.set_page_config(page_title='GrantAI Europe',page_icon='🇪🇺',layout='wide')

def load(path,default):
    try:return json.loads(path.read_text(encoding='utf-8'))
    except:return default

def save(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')

def normalise(hit):
    s=hit.get('_source',hit)
    return {'id':str(s.get('identifier') or s.get('callccm2Id') or s.get('reference') or ''),'reference':s.get('reference') or '', 'title':s.get('title') or '', 'status':s.get('status') or '', 'programme':s.get('frameworkProgramme') or '', 'action_type':s.get('typesOfAction') or '', 'deadline':s.get('deadlineDate') or '', 'description':s.get('description') or '', 'raw':s}

def search_calls(keyword,limit):
    query={'bool':{'must':[{'terms':{'type':['1','2','8']}},{'term':{'programmePeriod':'2021 - 2027'}}]}}
    params={'apiKey':'SEDIA','text':keyword.strip() or '***','pageSize':str(limit),'pageNumber':'1'}
    files={'query':('blob',json.dumps(query),'application/json'),'sort':('blob',json.dumps({'order':'ASC','field':'deadlineDate'}),'application/json'),'languages':('blob',json.dumps(['en']),'application/json'),'displayFields':('blob',json.dumps(['type','identifier','reference','callccm2Id','title','status','startDate','deadlineDate','frameworkProgramme','typesOfAction','description']),'application/json')}
    headers={'Accept':'application/json','Origin':'https://ec.europa.eu','Referer':'https://ec.europa.eu/','X-Requested-With':'XMLHttpRequest'}
    r=requests.post(EC_URL,params=params,files=files,headers=headers,timeout=45)
    r.raise_for_status();p=r.json()
    hits=p.get('results') or p.get('hits',{}).get('hits') or p.get('response',{}).get('docs') or []
    return [normalise(x) for x in hits]

def overlap(words,text):
    if not words:return 0
    t=text.lower();return min(100,100*sum(1 for w in words if w.lower().strip() in t)/len(words))

def dscore(v):
    if not v:return 50
    try:
        d=dtparser.parse(v)
        if d.tzinfo is None:d=d.replace(tzinfo=timezone.utc)
        days=(d-datetime.now(timezone.utc)).days
        return 100 if days>=120 else 80 if days>=60 else 55 if days>=30 else 30 if days>=14 else 5
    except:return 45

def score(call,profile,project):
    org=profile.get('organisation',{})
    corpus=' '.join(map(str,[call.get('title',''),call.get('description',''),call.get('programme',''),call.get('action_type','')]))
    th=overlap(project.get('keywords',[]),corpus);cap=overlap(org.get('capabilities',[])+org.get('sectors',[]),corpus);tim=dscore(str(call.get('deadline','')));elig=70;ev=75 if call.get('description') else 45
    total=th*.34+cap*.24+tim*.16+elig*.18+ev*.08
    return {'total':round(max(0,min(100,total)),1),'thematic_fit':round(th,1),'capability_fit':round(cap,1),'timing':round(tim,1),'eligibility_precheck':elig,'evidence_confidence':ev}

def api_key():
    try:return st.secrets.get('OPENAI_API_KEY','')
    except:return os.getenv('OPENAI_API_KEY','')

def make_draft(call,profile,project,language):
    if not api_key():raise RuntimeError('Lipsește OPENAI_API_KEY.')
    client=OpenAI(api_key=api_key())
    prompt=f'''You are a senior EU funding proposal strategist. Draft in {language}. Never invent facts, partners, budgets or results. Mark missing inputs [DE COMPLETAT]. Include eligibility risks, strategic fit, objectives, Excellence, Impact, KPIs, Implementation, work packages, consortium gaps, budget assumptions, compliance checklist and go/no-go.\nORGANISATION:{json.dumps(profile.get('organisation',{}),ensure_ascii=False)}\nPROJECT:{json.dumps(project,ensure_ascii=False)}\nCALL:{json.dumps(call,ensure_ascii=False)}'''
    return client.responses.create(model='gpt-4.1-mini',input=prompt).output_text

profile=load(PROFILE,{'organisation':{},'projects':[]});saved=load(SAVED,[])
st.title('🇪🇺 GrantAI Europe')
st.caption('Monitorizare, calificare și pregătire de aplicații pentru fonduri europene')
t1,t2,t3,t4=st.tabs(['Profil','Caută apeluri','Salvate','Generator'])
with t1:
    org=profile.setdefault('organisation',{});st.subheader('Organizație')
    c1,c2=st.columns(2);org['legal_name']=c1.text_input('Denumire',org.get('legal_name',''));org['country']=c2.text_input('Țară',org.get('country','Romania'));org['organisation_type']=c1.text_input('Tip',org.get('organisation_type','SME'));org['pic']=c2.text_input('PIC',org.get('pic',''))
    org['capabilities']=[x.strip() for x in st.text_area('Capabilități',', '.join(org.get('capabilities',[]))).split(',') if x.strip()]
    org['sectors']=[x.strip() for x in st.text_input('Sectoare',', '.join(org.get('sectors',[]))).split(',') if x.strip()]
    ps=profile.setdefault('projects',[])
    if not ps:ps.append({'name':'','summary':'','keywords':[]})
    p=ps[0];st.subheader('Proiect');p['name']=st.text_input('Nume proiect',p.get('name',''));p['summary']=st.text_area('Rezumat',p.get('summary',''));p['keywords']=[x.strip() for x in st.text_input('Cuvinte-cheie',', '.join(p.get('keywords',[]))).split(',') if x.strip()]
    if st.button('Salvează profilul',type='primary'):save(PROFILE,profile);st.success('Salvat.')
with t2:
    kw=st.text_input('Cuvinte-cheie','agriculture energy AI');limit=st.slider('Rezultate',10,100,30,10)
    if st.button('Caută apeluri',type='primary'):
        try:
            with st.spinner('Caut...'):
                project=profile.get('projects',[{}])[0];res=[{**x,**score(x,profile,project)} for x in search_calls(kw,limit)];res.sort(key=lambda x:x['total'],reverse=True);st.session_state['results']=res
            st.success(f'{len(res)} rezultate.')
        except Exception as e:st.error(str(e))
    res=st.session_state.get('results',[])
    if res:
        st.dataframe(pd.DataFrame([{'Scor':x['total'],'Referință':x['reference'],'Titlu':x['title'],'Program':x['programme'],'Deadline':x['deadline']} for x in res]),use_container_width=True,hide_index=True)
        i=st.selectbox('Selectează',range(len(res)),format_func=lambda i:f"{res[i]['total']}% — {res[i]['reference']} — {res[i]['title']}");sel=res[i];st.json({k:v for k,v in sel.items() if k!='raw'})
        if st.button('Salvează oportunitatea'):
            if sel.get('id') not in {x.get('id') for x in saved}:saved.append(sel);save(SAVED,saved)
            st.success('Salvată.')
with t3:
    if not saved:st.info('Nicio oportunitate salvată.')
    else:
        st.dataframe(pd.DataFrame([{'Scor':x.get('total'),'Referință':x.get('reference'),'Titlu':x.get('title'),'Deadline':x.get('deadline')} for x in saved]),use_container_width=True,hide_index=True)
        st.download_button('Descarcă JSON',json.dumps(saved,ensure_ascii=False,indent=2),'oportunitati.json','application/json')
with t4:
    if not saved:st.warning('Salvează întâi un apel.')
    else:
        i=st.selectbox('Apel',range(len(saved)),format_func=lambda i:f"{saved[i].get('reference','')} — {saved[i].get('title','')}");lang=st.selectbox('Limba',['Romanian','English'])
        if st.button('Generează draft',type='primary'):
            try:
                with st.spinner('Generez...'):st.session_state['draft']=make_draft(saved[i],profile,profile.get('projects',[{}])[0],lang)
            except Exception as e:st.error(str(e))
        if st.session_state.get('draft'):
            st.markdown(st.session_state['draft']);st.download_button('Descarcă draft',st.session_state['draft'],'draft.md','text/markdown')
st.divider();st.caption('Datele juridice, financiare, partenerii și depunerea finală trebuie verificate de o persoană autorizată.')
