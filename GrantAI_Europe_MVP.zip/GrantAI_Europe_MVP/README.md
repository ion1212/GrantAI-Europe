# GrantAI Europe MVP
Aplicație web pentru profil, căutare apeluri UE, scor automat, salvare oportunități și generare drafturi.

Publicare recomandată: GitHub + Render. Setează variabila secretă OPENAI_API_KEY.
